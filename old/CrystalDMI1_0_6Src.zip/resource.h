//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CrystalDMI.rc
//
#define IDD_CRYSTALDMI_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDR_MENU                        130
#define IDR_ACCELERATOR                 131
#define IDC_SELECT                      1000
#define IDC_VIEW                        1001
#define ID_DUMMY                        1005
#define IDM_EXIT                        32771
#define IDM_COPY_TEXT                   32772
#define IDM_READ_ME                     32773
#define IDM_CRYSTAL_DEW_WORLD           32774
#define IDM_LICENSE                     32775
#define IDM_JAPANESE                    32776
#define IDM_ENGLISH                     32777
#define IDM_DUMP_BIOS                   32778
#define IDM_DUMP_VGA                    32779
#define IDM_DUMP_EX_BIOS                32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
